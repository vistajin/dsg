SELECT
    distinct cast(c.isoldmat as bit) isoldmat,
    a.remark as senddetailremark,a.docno,a.line,a.dline,a.barcodeno,a.locationid,a.matno,
    a.batchid,a.volumeid,a.package,a.qtyi,a.qunit, a.sampleqty,
    a.wunit,a.conversion,a.lunit ,a.length sqlength,a.resno,a.resline,
    a.templetid, a.styleno,a.pre_number,a.pre_line,
    case when (a.conversion>0) then mm.weight/a.conversion*a.sampleqty else 0 end as sflength,
    --case when (a.conversion>0 AND a.storeno<>'A' ) then mm.weight/a.conversion*a.sampleqty else a.length end as sflength,
    b.MocType,b.SendDate,b.ReceiveDpt,b.makedeptdesc,b.usetype,b.SendUser,b.inuser,
    b.checkuser,b.checkdate,b.storecheckdate,b.confirmPrintCnt  printcount ,
    b.branchid,b.remark AS remarkm,
    isnull(b.tobldate, a.tobldate)  tobldate,
    isnull(b.bluserid , a.bluserid ) bluserid,
    isnull(b.blusername, a.blusername ) blusername,
    b.tojjdate tojjdate,  b.jjusername  jjusername, b.jjuserid,
    b.confirmPrintDate printdate, b.confirmPrintUser  printuser,
    b.isTempMatFlag,b.factory_desc,
    c.dsgpoperson,c.StoreNo,c.matDesc,c.poprice,c.colorid,c.colordesc,c.season,
    c.mattype,c.crockid,C.orderno,c.banid ,c.styleno as oldstyleno, c.dsgstyle,
    d.mattypename,d.mattypedesc,
    case  when e.checkdate='1900-01-01 00:00:00.000'  then null else e.CheckDate end    as outdate ,
    e.moctype as outmoctype,e.checkflag, e.pdauserid,e.docno as outno,
    e.factorycheckflag,e.factorycheckdate,e.factorycheckuser,
    f.length storelength,f.weight storeweight,
    case when f.Length-ISNULL(y.length,0)<0 then 0 else f.Length-ISNULL(y.length,0) end as avlength,
    case when f.weight-ISNULL(y.qtyi,0)<0 then 0 else f.weight-ISNULL(y.qtyi,0) end  as avweight ,
    h.username,q.username as checkname,mm.weight weight,w.username as pdausername,
    res.Senddate as yldate,res.senduser as yluser,
    cast((case when res.docno is null  then 1 else 0 end   ) as bit) as isusestoreflag,
    yy.username as  storecheckuser ,
    (Case when isnull(mc.length,0)>0 then mc.length else mr.length end) as inlength,
    (Case when isnull(mc.weight,0)>0 then mc.weight else mr.weight end) as inweight,
    mh.OrderTjkRemark,mh.checkdate as storeindate
FROM MaterialSend_DetailD a (nolock)
inner join MaterialSend_head (nolock) b on a.DocNo=b.DocNo
left join MaterialSend_Detail (nolock) g on a.DocNo=g.DocNo and a.line=g.line
left join MaterialOut_Head (nolock) e on b.docno=e.sendno
left join MaterialOut_Detail mm on e.docno=mm.docno and a.batchid=mm.batchid
left join materialbatchinfo c(NOLOCK) on a.batchid=c.batchid
left join MaterialstoreQty (nolock) f on a.batchid=f.batchid
left join(
    SELECT resh.docno,resh.Senddate,resh.senduser,resh.ReceiveDpt,resd.dline
    FROM MaterialSend_head (nolock) resh
    LEFT JOIN MaterialSend_DetailD (nolock) resd ON resh.docno=resd.docno) res on res.docno=a.resno and res.dline=a.resline
left join (
    select c.batchid,sum(c.length) as length,sum(c.qtyi) as qtyi
    from MaterialSend_DetailD (nolock) c
    left join MaterialSend_Head (nolock) d on c.docno=d.docno
    left join materialout_head (nolock) e on d.DocNo=e.SendNo
    where d.checkflag=1 and d.DocNo not like 'RES%' and e.DocNo is null and c.resno is null
    group by c.batchid) y on y.batchid=a.batchid
left join s_users (nolock) h on h.userid=b.inuser
left join s_users (nolock) w on w.userid=e.pdauserid
left join s_users (nolock) q on q.userid=b.checkuser
left join s_users(nolock) yy on yy.userid=b.storecheckuser
left join materialtype (nolock) d on c.mattype=d.mattypeid
left join MaterialCollect_detail  mc (nolock) on a.batchid=mc.batchid
left join MaterialCollect_head mh (nolock) on mc.docno=mh.docno
Left join MaterialReturnStore_Detail(nolock) mr on mr.newbatchid=a.batchid
Left join MaterialBeiLiao mbl on mbl.sendno=a.docno
where 1=1 and
    a.DocNo not like 'RES%'
    and b.sendDate>='2017-05-01 00:00:00'
    and b.SendDate<='2017-08-25 08:51:23'
    and b.DocNo like '%BCK%'
Order by b.senddate,a.docno,a.dline



----dev
-----before tune 
SQL Server 分析和编译时间: 
   CPU 时间 = 0 毫秒，占用时间 = 0 毫秒。

 SQL Server 执行时间:
   CPU 时间不是在纤程模式下测量的，占用时间 = 0 毫秒。
SQL Server 分析和编译时间: 
   CPU 时间 = 0 毫秒，占用时间 = 2118 毫秒。

 SQL Server 执行时间:
   CPU 时间不是在纤程模式下测量的，占用时间 = 0 毫秒。

 SQL Server 执行时间:
   CPU 时间不是在纤程模式下测量的，占用时间 = 0 毫秒。

(208 行受影响)
表 'MaterialReturnStore_Detail'。扫描计数 41，逻辑读取 2762 次，物理读取 0 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 'MaterialCollect_detail'。扫描计数 41，逻辑读取 15624 次，物理读取 0 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 's_users'。扫描计数 164，逻辑读取 324 次，物理读取 0 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 'MaterialOut_Head'。扫描计数 82，逻辑读取 15750 次，物理读取 0 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 'MaterialSend_head'。扫描计数 123，逻辑读取 24133 次，物理读取 0 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 'MaterialSend_DetailD'。扫描计数 132，逻辑读取 55972 次，物理读取 0 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 'Worktable'。扫描计数 414，逻辑读取 1532 次，物理读取 0 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 'MaterialStoreQty'。扫描计数 41，逻辑读取 6775 次，物理读取 0 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 'Worktable'。扫描计数 0，逻辑读取 0 次，物理读取 0 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 'MaterialOut_Detail'。扫描计数 41，逻辑读取 77474 次，物理读取 0 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 'MaterialType'。扫描计数 0，逻辑读取 412 次，物理读取 0 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 'materialbatchinfo'。扫描计数 0，逻辑读取 618 次，物理读取 0 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 'MaterialCollect_Head'。扫描计数 0，逻辑读取 750 次，物理读取 0 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。

 SQL Server 执行时间:
   CPU 时间不是在纤程模式下测量的，占用时间 = 1885 毫秒。






---after tune
 SQL Server 执行时间:
   CPU 时间不是在纤程模式下测量的，占用时间 = 0 毫秒。
表 'MaterialSend_head'。扫描计数 1，逻辑读取 747 次，物理读取 0 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。

 SQL Server 执行时间:
   CPU 时间不是在纤程模式下测量的，占用时间 = 695 毫秒。

(375 行受影响)
SQL Server 分析和编译时间: 
   CPU 时间 = 0 毫秒，占用时间 = 1617 毫秒。

(208 行受影响)
表 'MaterialReturnStore_Detail'。扫描计数 208，逻辑读取 715 次，物理读取 0 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 'MaterialCollect_Head'。扫描计数 0，逻辑读取 622 次，物理读取 0 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 'MaterialCollect_detail'。扫描计数 208，逻辑读取 1295 次，物理读取 0 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 'Worktable'。扫描计数 416，逻辑读取 1657 次，物理读取 0 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 'MaterialOut_Head'。扫描计数 2135，逻辑读取 7105 次，物理读取 0 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 'MaterialSend_head'。扫描计数 0，逻辑读取 9105 次，物理读取 0 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 'MaterialSend_DetailD'。扫描计数 585，逻辑读取 8064 次，物理读取 0 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 'MaterialStoreQty'。扫描计数 208，逻辑读取 1315 次，物理读取 0 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 'materialbatchinfo'。扫描计数 0，逻辑读取 646 次，物理读取 0 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 'MaterialOut_Detail'。扫描计数 208，逻辑读取 959 次，物理读取 0 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 '#DocNoLike__________________________________________________________________________________________________________000000000F0D'。扫描计数 1，逻辑读取 2 次，物理读取 0 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 's_users'。扫描计数 4，逻辑读取 290 次，物理读取 0 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 'MaterialType'。扫描计数 1，逻辑读取 3 次，物理读取 0 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。

 SQL Server 执行时间:
   CPU 时间不是在纤程模式下测量的，占用时间 = 133 毫秒。

 SQL Server 执行时间:
   CPU 时间不是在纤程模式下测量的，占用时间 = 0 毫秒。

 SQL Server 执行时间:
   CPU 时间不是在纤程模式下测量的，占用时间 = 1 毫秒。















----prod

--before tune

SQL Server 分析和编译时间: 
   CPU 时间 = 0 毫秒，占用时间 = 0 毫秒。

 SQL Server 执行时间:
   CPU 时间 = 0 毫秒，占用时间 = 0 毫秒。
SQL Server 分析和编译时间: 
   CPU 时间 = 0 毫秒，占用时间 = 0 毫秒。

 SQL Server 执行时间:
   CPU 时间 = 0 毫秒，占用时间 = 0 毫秒。

 SQL Server 执行时间:
   CPU 时间 = 0 毫秒，占用时间 = 0 毫秒。

(208 行受影响)
表 'MaterialReturnStore_Detail'。扫描计数 65，逻辑读取 2762 次，物理读取 0 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 's_users'。扫描计数 206，逻辑读取 964 次，物理读取 0 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 'Worktable'。扫描计数 0，逻辑读取 0 次，物理读取 0 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 'MaterialOut_Detail'。扫描计数 208，逻辑读取 1003 次，物理读取 0 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 'MaterialOut_Head'。扫描计数 273，逻辑读取 4390 次，物理读取 0 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 'MaterialSend_DetailD'。扫描计数 180，逻辑读取 62373 次，物理读取 0 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 'MaterialSend_head'。扫描计数 174，逻辑读取 15677 次，物理读取 0 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 'MaterialStoreQty'。扫描计数 65，逻辑读取 7863 次，物理读取 0 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 'Worktable'。扫描计数 414，逻辑读取 1466 次，物理读取 0 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 'MaterialType'。扫描计数 0，逻辑读取 412 次，物理读取 0 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 'materialbatchinfo'。扫描计数 0，逻辑读取 618 次，物理读取 0 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 'MaterialCollect_Head'。扫描计数 0，逻辑读取 639 次，物理读取 0 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 'MaterialCollect_detail'。扫描计数 208，逻辑读取 1352 次，物理读取 0 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。

 SQL Server 执行时间:
   CPU 时间 = 330727 毫秒，占用时间 = 44605 毫秒。




 SQL Server 执行时间:
   CPU 时间 = 0 毫秒，占用时间 = 0 毫秒。

(208 行受影响)
表 'MaterialReturnStore_Detail'。扫描计数 65，逻辑读取 2762 次，物理读取 71 次，预读 3102 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 'MaterialCollect_detail'。扫描计数 65，逻辑读取 16244 次，物理读取 421 次，预读 16321 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 's_users'。扫描计数 260，逻辑读取 964 次，物理读取 0 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 'MaterialStoreQty'。扫描计数 65，逻辑读取 7257 次，物理读取 192 次，预读 7282 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 'Worktable'。扫描计数 0，逻辑读取 0 次，物理读取 0 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 'MaterialOut_Detail'。扫描计数 208，逻辑读取 1681 次，物理读取 1 次，预读 216 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 'MaterialOut_Head'。扫描计数 273，逻辑读取 4384 次，物理读取 21 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 'MaterialSend_DetailD'。扫描计数 180，逻辑读取 62186 次，物理读取 916 次，预读 61119 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 'MaterialSend_head'。扫描计数 195，逻辑读取 15636 次，物理读取 42 次，预读 1185 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 'Worktable'。扫描计数 414，逻辑读取 1466 次，物理读取 0 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 'MaterialType'。扫描计数 0，逻辑读取 412 次，物理读取 0 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 'materialbatchinfo'。扫描计数 0，逻辑读取 618 次，物理读取 196 次，预读 0 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。
表 'MaterialCollect_Head'。扫描计数 0，逻辑读取 1173 次，物理读取 0 次，预读 1160 次，lob 逻辑读取 0 次，lob 物理读取 0 次，lob 预读 0 次。

 SQL Server 执行时间:
   CPU 时间 = 407003 毫秒，占用时间 = 15168 毫秒。
   
--after tune

