SELECT CP.usecounts AS CountOfQueryExecution,
CP.cacheobjtype AS CacheObjectType,
CP.objtype AS ObjectType,
ST.text AS QueryText
FROM sys.dm_exec_cached_plans AS CP
CROSS APPLY sys.dm_exec_sql_text(plan_handle) AS ST
WHERE CP.usecounts > 0
GO

SELECT SUM(size_in_bytes) AS TotalByteConsumedByAdHoc
FROM sys.dm_exec_cached_plans
WHERE objtype = 'Adhoc'
AND usecounts = 1


SELECT CP.usecounts AS CountOfQueryExecution,
CP.cacheobjtype AS CacheObjectType,
CP.objtype AS ObjectType,
ST.text AS QueryText
FROM sys.dm_exec_cached_plans AS CP
CROSS APPLY sys.dm_exec_sql_text(plan_handle) AS ST
WHERE CP.usecounts > 0 and ST.text like 'Select cast(0 as bit ) as selectflag%'
GO

DBCC FREEPROCCACHE
GO

DBCC MemoryStatus