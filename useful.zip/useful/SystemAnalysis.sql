
--- database user connection
  
--��SSMS��ѡ�����ı���ʽ��ʾ���
SELECT TOP 10 
dest.[text] AS 'sql���'
FROM sys.[dm_exec_requests] AS der 
CROSS APPLY 
sys.[dm_exec_sql_text](der.[sql_handle]) AS dest 
WHERE [session_id]>50  
ORDER BY [cpu_time] DESC

SELECT
scheduler_address,
scheduler_id,
cpu_id,
status,
current_tasks_count,
current_workers_count,active_workers_count
FROM sys.dm_os_schedulers



---waiting worker

SELECT 
 [session_id],
 [request_id],
 [start_time] AS '��ʼʱ��',
 [status] AS '״̬',
 [command] AS '����',
 dest.[text] AS 'sql���', 
 DB_NAME([database_id]) AS '���ݿ���',
 [blocking_session_id] AS '�������������Ự�ĻỰID',
 der.[wait_type] AS '�ȴ���Դ����',
 [wait_time] AS '�ȴ�ʱ��',
 [wait_resource] AS '�ȴ�����Դ',
 [dows].[waiting_tasks_count] AS '��ǰ���ڽ��еȴ���������',
 [reads] AS '����������',
 [writes] AS 'д����',
 [logical_reads] AS '�߼�������',
 [row_count] AS '���ؽ������'
 FROM sys.[dm_exec_requests] AS der 
 INNER JOIN [sys].[dm_os_wait_stats] AS dows 
 ON der.[wait_type]=[dows].[wait_type]
 CROSS APPLY 
 sys.[dm_exec_sql_text](der.[sql_handle]) AS dest 
 WHERE [session_id]>50  
 ORDER BY [cpu_time] DESC
 
 
 ---top 10 cpu
 
SELECT TOP 10
   total_worker_time/execution_count AS avg_cpu_cost, plan_handle,
   execution_count,
   (SELECT SUBSTRING(text, statement_start_offset/2 + 1,
      (CASE WHEN statement_end_offset = -1
         THEN LEN(CONVERT(nvarchar(max), text)) * 2
         ELSE statement_end_offset
      END - statement_start_offset)/2)
   FROM sys.dm_exec_sql_text(sql_handle)) AS query_text
FROM sys.dm_exec_query_stats
ORDER BY [avg_cpu_cost] DESC


-- ��ѯȱʧ����
SELECT 
    DatabaseName = DB_NAME(database_id)
    ,[Number Indexes Missing] = count(*) 
FROM sys.dm_db_missing_index_details
GROUP BY DB_NAME(database_id)
ORDER BY 2 DESC;


select * from sys.dm_db_missing_index_details


--
SELECT  TOP 10 
        [Total Cost]  = ROUND(avg_total_user_cost * avg_user_impact * (user_seeks + user_scans),0) 
        , avg_user_impact
        , TableName = statement
        , [EqualityUsage] = equality_columns 
        , [InequalityUsage] = inequality_columns
        , [Include Cloumns] = included_columns
FROM        sys.dm_db_missing_index_groups g 
INNER JOIN    sys.dm_db_missing_index_group_stats s 
       ON s.group_handle = g.index_group_handle 
INNER JOIN    sys.dm_db_missing_index_details d 
       ON d.index_handle = g.index_handle
ORDER BY [Total Cost] DESC;