USE [dsg]
GO

/****** Object:  View [dbo].[vm_BatchSendQty]    Script Date: 09/23/2017 18:53:34 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



 
/*cyueyong 20170915 领料数量运算*/    
CREATE VIEW [dbo].[vm_BatchSendQty]    
AS    
   
select a.BatchID,a.MatNo,a.volumeid,a.mattype,a.mattypename,a.mattypedesc,a.MatDesc,a.OrderNo,a.line,a.orderserial,a.lockflag,                                                                                                      
       a.ColorID,a.ColorDesc,a.Season,a.reqperson,a.Designer,a.dsgdeptdesc,a.supplierid, a.SupplierDesc,a.Package,a.batch,    
       a.conversion,a.crockid,a.dsgpoperson,a.poprice,a.isoldmat,a.storeno,a.podept,a.podeptdesc,a.reqdept,a.reqdeptdesc,    
       a.revperson,a.supply_colorname,a.part,a.dsgstyle,a.element,a.needqty,a.banid,a.goodsperiod,a.styleno,a.rev_number,                                                                                                                                                                                                                                        
       a.clothareano,a.weight as kz,a.dsgclothareano,a.itemtype,            
       b.LocationID,b.sampleqty,a.Lunit,a.Wunit,                                                
       b.Length as StoreLength,--库存数量                                                                       
       b.weight as StoreWeight,--库存重量                                                               
       case WHEN isnull(f.length,0)-isnull(h.length,0) < 0 THEN b.length-isnull(e.length,0)                                                               
            WHEN b.length-isnull(e.length,0)-isnull(i.length,0)-(isnull(f.length,0)-isnull(h.length,0)) < 0 THEN 0                                                                  
            else b.length-isnull(e.length,0)-isnull(i.length,0)-(isnull(f.length,0)-isnull(h.length,0))                                                               
       end  as  avnoreslength,  --实际可用数量= 库存-正常未出-预留未出-预留剩余                                                                                                    
       case WHEN isnull(f.qtyi,0)-isnull(h.qtyi,0) < 0 THEN b.weight-isnull(e.qtyi,0)                                                              
            WHEN b.weight-isnull(e.qtyi,0)-isnull(i.qtyi,0)-(isnull(f.qtyi,0)-isnull(h.qtyi,0)) < 0 THEN 0                                                              
            else b.weight-isnull(e.qtyi,0)-isnull(i.qtyi,0)-(isnull(f.qtyi,0)-isnull(h.qtyi,0))                                                               
       end as  avnoresweight  --实际可用重量                                                                                                                                                                                                                                                                                                                                                                                        
     from materialbatchinfo (nolock) a                                        
left join MaterialStoreQty (nolock) b on b.BatchID=a.BatchID                                                                                                                     
left join (select batchid, SUM(length)as length,SUM(qtyi) as qtyi                                                                                                 
          from materialsend_detaild(nolock) a                                       
          inner join  materialsend_head(nolock)  d on a.docno=d.docno                                        
          left join   materialout_head(nolock) c on a.docno=c.sendno                                                                                               
          where d.checkflag=1 and a.docno like 'SED%' and   isnull(a.resno,'')=''  and  isnull(c.docno,'')=''                                                                                            
          group by BatchID                                                                                                
          ) e on a.batchid=e.batchid  --e正常领料未出货                                      
left join (select batchid, SUM(length)as length,SUM(qtyi) as qtyi                                                                    
          from materialsend_detaild(nolock) a inner join                                                                                         
          materialsend_head(nolock)  d on a.docno=d.docno                                                                                            
          where d.checkflag=1 and a.docno  like 'RES%'                                                                                            
          group by BatchID                                                  
         ) f on a.batchid=f.batchid  --f 预留数量                                    
left join  (select batchid, SUM(length)as length,  SUM(qtyi) as qtyi                                                                      
          from materialsend_detaild(nolock) a inner join                                                                                         
          materialsend_head(nolock)  d on a.docno=d.docno                                                                                 
          where d.checkflag=1    and a.resno  like 'RES%'                          
          group by BatchID                                                                                                
          ) h on a.batchid=h.batchid  --h  领预留数量    
left join  (select batchid, SUM(length)as length,  SUM(qtyi) as qtyi                                                                      
          from materialsend_detaild(nolock) a inner join                                                                                         
          materialsend_head(nolock)  d on a.docno=d.docno    
          left join   materialout_head c(nolock) on a.docno=c.sendno                                                                                 
          where d.checkflag=1  and a.docno like 'SED%'  and  a.resno like 'RES%' and c.docno is null                         
          group by BatchID                                                                                                
          ) i on i.batchid=a.batchid  --i  领预留未出数量    
Where b.Length>0 and b.Weight>0    
            



GO

