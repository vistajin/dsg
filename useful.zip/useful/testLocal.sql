update s_desctext set desctext=
'exec spMaterialByBatchIDSend :BATCHID,:LOCATIONID,:ORDERNO,:ITEM_CODE,:REQPERSON,:SUPPLY,:SEASON,:DESIGNER,:TRACKUSER,:PUTFLAG,:MATTYPE,:ISNEWFLAG,:COLORNAME,:COLORDESC,:ITEMDESC,:LOGINID,:CROCKID,:NOINDOCNO,:STORENO,:BANID,:REVNUMBER,:REQNAME,:TRACGPNAME,:ipaddress,:isImportPDAData,:docType,:pdaDocNo,:styleno,:bantype,:receivedpt' where groupname='qryselectspMaterialByBatchID'


 
select top 100 * from dsg_log.dbo.s_log where type = '����' and logindate > '20157-09-01 10:36:38.000' ;


select a.DocNo,COUNT(1),MAX(SendDate) from dsg_test.dbo.MaterialSend_head a left join 
dsg_test.dbo.MaterialSend_DetailD b on a.DocNo=b.DocNo 
where a.DocNo like 'SED%' and
SendDate between '2017-09-01 23:02:44.063' and '2017-09-22 23:02:44.063' 
group by a.DocNo
order by SendDate ASC

select TOP 100 * from dsg_test.dbo.MaterialSend_DetailD;

select COUNT(1) from dsg_log.dbo.ban_makebill_head_log

select request_session_id spid,*,request_session_id spid,OBJECT_NAME(resource_associated_entity_id) tableName 
from sys.dm_tran_locks where resource_type='OBJECT'

select * from sys.dm_tran_locks where resource_type='OBJECT'

exec sp_who2 62


  

 
