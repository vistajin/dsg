package com.dsg;

import java.io.IOException;
import java.io.OutputStream;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import com.dsg.export.SqlServerUtils;

/**
 * Servlet implementation class ExportSvlt
 */
@WebServlet("/ExportSvlt")
public class ExportSvlt extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ExportSvlt() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Connection conn = null;
		PreparedStatement ps = null;
		HSSFWorkbook wb = new HSSFWorkbook();
		HSSFSheet sheet = wb.createSheet("sheet1");
		try {
			conn = SqlServerUtils.getConnection();			
			CallableStatement cs = conn.prepareCall("{call sp_export(?)}");
			cs.setInt(1, 1);
			ResultSet rs = cs.executeQuery();
			long start = System.currentTimeMillis();
			int rowNum = 0;
			int colNum = 0;
			ResultSetMetaData rsmd = rs.getMetaData() ;   
			int columnCount = rsmd.getColumnCount();  
			while (rs.next()) {
				HSSFRow row = sheet.createRow(rowNum);
				for (int i = 1; i <= columnCount; i++) {
					HSSFCell cell = row.createCell(colNum);
					cell.setCellValue(rs.getString(i));
					colNum++;
				}
				colNum = 0;
				rowNum++;
			}
			rs.close();
			
			OutputStream out = response.getOutputStream();
			response.setHeader("Content-Type", "application/vnd.ms-excel");
			response.addHeader("Content-Disposition", "attachment;filename=mydata.xls");
			response.setContentType("application/octet-stream");
			response.setCharacterEncoding("UTF-8");
			
			wb.write(out);
			out.close();
			long end = System.currentTimeMillis();
			System.out.println("Write excel file spend: " + (end - start));
		} catch (Exception e) {
			System.err.println("Failed to export.");
			e.printStackTrace();
		} finally {
			SqlServerUtils.closeStatement(ps);
			SqlServerUtils.closeConnection(conn);
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
